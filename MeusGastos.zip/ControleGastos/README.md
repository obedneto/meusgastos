# Meus Gastos — como gerar e instalar o APK

## O que o app faz
- Lê o SMS de compra do **Bradesco Cartões** e lança o gasto sozinho (valor + estabelecimento + categoria).
- Dashboard do mês: rosca por categoria (Alimentação, Despesa fixa, Lazer, Transporte, Saúde, Compras, Outros), total e % de cada uma. Setas para ver outros meses.
- Botão **+** para lançar à mão; toque num lançamento para editar; lixeira para remover.
- Se você muda a categoria de um estabelecimento, as próximas compras nele já entram na categoria certa.
- Widget na tela inicial com o total do mês e um **+** para lançar rápido.
- Botão **Capturas**: mostra os últimos SMS do Bradesco e se foram registrados ou ignorados.

## 1. Gerar o APK (sem instalar nada no PC)
1. Crie uma conta grátis em github.com e clique em **New repository** (pode ser privado).
2. Na página do repositório: **Add file → Upload files** e arraste **todo o conteúdo** desta pasta
   (inclusive a pasta `.github`). Clique em **Commit changes**.
3. Abra a aba **Actions**. A tarefa **Gerar APK** roda sozinha (~5 min).
   Se não rodar: clique em **Gerar APK → Run workflow**.
4. Quando ficar verde, abra a execução e baixe **MeusGastos-apk** (vem em .zip; dentro está `app-debug.apk`).

> Se a pasta `.github` não subir: em **Actions → set up a workflow yourself**, cole o conteúdo de
> `.github/workflows/build-apk.yml` e salve.

Alternativa: abra a pasta no **Android Studio** e clique em **Run** com o celular conectado.

## 2. Instalar no celular
1. Passe o `app-debug.apk` para o celular e abra. Autorize **instalar apps desconhecidos**.
2. **Android 13 ou mais novo:** antes de dar a permissão de SMS, vá em
   **Configurações → Apps → Meus Gastos → ⋮ (canto superior) → Permitir configurações restritas**.
   Sem isso o Android bloqueia a leitura de SMS de apps instalados por APK.
3. Abra o app e toque em **Permitir SMS**.
4. Widget: segure na tela inicial → **Widgets** → **Meus Gastos**.

## Se uma compra não for registrada
Abra **Capturas**, copie o texto do SMS marcado como "ignorado" e ajuste as regras em
`app/src/main/java/com/obed/gastos/sms/PurchaseParser.kt` (ou mande o texto para o Claude ajustar).
Compras estornadas, canceladas ou negadas são ignoradas de propósito.

Os dados ficam só no celular (banco SQLite local).
