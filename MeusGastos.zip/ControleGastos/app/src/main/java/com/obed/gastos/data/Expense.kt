package com.obed.gastos.data

data class Expense(
    val id: Long = 0,
    val amountCents: Long,
    val description: String,
    val category: Category,
    val timestamp: Long,
    /** "manual" ou "sms" */
    val source: String,
)

enum class Category(val label: String, val color: Long) {
    ALIMENTACAO("Alimentação", 0xFF2E7D32),
    DESPESA_FIXA("Despesa fixa", 0xFF1565C0),
    LAZER("Lazer", 0xFFEF6C00),
    TRANSPORTE("Transporte", 0xFF6A1B9A),
    SAUDE("Saúde", 0xFFC62828),
    COMPRAS("Compras", 0xFF00838F),
    OUTROS("Outros", 0xFF757575);

    companion object {
        fun from(name: String?): Category = entries.firstOrNull { it.name == name } ?: OUTROS
    }
}
