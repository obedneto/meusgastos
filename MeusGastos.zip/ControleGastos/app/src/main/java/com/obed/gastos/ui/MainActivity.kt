package com.obed.gastos.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.obed.gastos.data.Categorizer
import com.obed.gastos.data.Category
import com.obed.gastos.data.Expense
import com.obed.gastos.data.ExpenseDb
import com.obed.gastos.data.Money
import com.obed.gastos.data.Periods
import com.obed.gastos.sms.DiagLog
import com.obed.gastos.widget.QuickAddWidget

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GastosTheme { MainScreen(resumeTick) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++ // recarrega a lista quando volta ao app (pode ter chegado SMS)
    }
}

/** Janela aberta pelo "+" do widget. */
class AddExpenseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GastosTheme {
                ExpenseDialog(
                    initial = null,
                    onDismiss = { finish() },
                    onSave = { e ->
                        ExpenseDb.get(this).insert(e)
                        QuickAddWidget.refreshAll(this)
                        Toast.makeText(this, "Despesa lançada: ${Money.fmt(e.amountCents)}", Toast.LENGTH_SHORT).show()
                        finish()
                    },
                )
            }
        }
    }
}

@Composable
fun GastosTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(ctx)
        Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(refreshKey: Int) {
    val ctx = LocalContext.current
    val db = remember { ExpenseDb.get(ctx) }

    var monthOffset by remember { mutableIntStateOf(0) }
    var version by remember { mutableIntStateOf(0) }
    val range = remember(monthOffset) { Periods.month(monthOffset) }
    val expenses = remember(range, version, refreshKey) { db.byPeriod(range.first, range.second) }

    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Expense?>(null) }
    var toDelete by remember { mutableStateOf<Expense?>(null) }
    var showDiag by remember { mutableStateOf(false) }

    var smsOn by remember(refreshKey) {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        )
    }
    val smsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { smsOn = it }

    fun changed() {
        version++
        QuickAddWidget.refreshAll(ctx)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Meus Gastos") },
                actions = { TextButton(onClick = { showDiag = true }) { Text("Capturas") } },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) {
                Icon(Icons.Default.Add, contentDescription = "Adicionar despesa")
            }
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (!smsOn) item {
                SetupCard(onAllow = { smsLauncher.launch(Manifest.permission.RECEIVE_SMS) })
            }
            item {
                MonthHeader(
                    label = Periods.monthLabel(range.first),
                    onPrev = { monthOffset-- },
                    onNext = { monthOffset++ },
                )
            }
            item { SummaryCard(expenses) }
            item {
                Text(
                    "Lançamentos (${expenses.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            if (expenses.isEmpty()) item {
                Text("Nenhum gasto neste mês.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(expenses, key = { it.id }) { e ->
                ExpenseRow(e, onClick = { editing = e }, onDelete = { toDelete = e })
            }
        }
    }

    if (adding) ExpenseDialog(
        initial = null,
        onDismiss = { adding = false },
        onSave = { db.insert(it); adding = false; changed() },
    )

    editing?.let { old ->
        ExpenseDialog(
            initial = old,
            onDismiss = { editing = null },
            onSave = { new ->
                db.update(new)
                if (new.category != old.category) db.saveRule(Categorizer.key(new.description), new.category)
                editing = null
                changed()
            },
        )
    }

    toDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Remover despesa?") },
            text = { Text("${e.description} · ${Money.fmt(e.amountCents)}") },
            confirmButton = {
                TextButton(onClick = { db.delete(e.id); toDelete = null; changed() }) { Text("Remover") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }

    if (showDiag) {
        val log = remember { DiagLog.read(ctx) }
        AlertDialog(
            onDismissRequest = { showDiag = false },
            title = { Text("SMS do Bradesco recebidos") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        "Se uma compra aparecer como ignorada, copie o texto para ajustar a leitura.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.size(8.dp))
                    if (log.isEmpty()) Text("Nenhum SMS do Bradesco recebido ainda.")
                    SelectionContainer {
                        Column {
                            log.forEach {
                                Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
                                HorizontalDivider()
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDiag = false }) { Text("Fechar") } },
        )
    }
}

@Composable
private fun SetupCard(onAllow: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ativar leitura automática", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("Permita a leitura de SMS para registrar as compras do cartão Bradesco sozinho.")
            Button(onClick = onAllow) { Text("Permitir SMS") }
        }
    }
}

@Composable
private fun MonthHeader(label: String, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onPrev) { Icon(Icons.Default.KeyboardArrowLeft, "Mês anterior") }
        Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        IconButton(onClick = onNext) { Icon(Icons.Default.KeyboardArrowRight, "Próximo mês") }
    }
}

@Composable
private fun SummaryCard(expenses: List<Expense>) {
    val total = expenses.sumOf { it.amountCents }
    val byCat = expenses.groupBy { it.category }
        .mapValues { (_, l) -> l.sumOf { it.amountCents } }
        .toList()
        .sortedByDescending { it.second }
    val track = MaterialTheme.colorScheme.surfaceVariant

    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(130.dp)) {
                    val stroke = 22.dp.toPx()
                    val tl = Offset(stroke / 2, stroke / 2)
                    val arc = Size(size.width - stroke, size.height - stroke)
                    drawArc(track, 0f, 360f, false, tl, arc, style = Stroke(stroke))
                    var start = -90f
                    if (total > 0) byCat.forEach { (c, v) ->
                        val sweep = 360f * v / total
                        drawArc(Color(c.color), start, sweep, false, tl, arc, style = Stroke(stroke))
                        start += sweep
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Total", style = MaterialTheme.typography.labelSmall)
                    Text(Money.fmt(total), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (byCat.isEmpty()) Text("Sem gastos", color = MaterialTheme.colorScheme.onSurfaceVariant)
                byCat.forEach { (c, v) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(Color(c.color), CircleShape))
                        Spacer(Modifier.width(6.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.label, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            Text(
                                "${Money.fmt(v)} · ${(v * 100 / total)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpenseRow(e: Expense, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(Color(e.category.color), CircleShape))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(e.description, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    "${e.category.label} · ${Periods.short(e.timestamp)}" + if (e.source == "sms") " · SMS" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(Money.fmt(e.amountCents), fontWeight = FontWeight.SemiBold)
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Remover") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ExpenseDialog(initial: Expense?, onDismiss: () -> Unit, onSave: (Expense) -> Unit) {
    var amount by remember { mutableStateOf(initial?.let { Money.toInput(it.amountCents) } ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var cat by remember { mutableStateOf(initial?.category ?: Category.ALIMENTACAO) }
    var error by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nova despesa" else "Editar despesa") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it; error = false },
                    label = { Text("Valor (R$)") },
                    singleLine = true,
                    isError = error,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                if (error) Text("Informe um valor válido", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Descrição") },
                    singleLine = true,
                )
                Text("Categoria", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Category.entries.forEach { c ->
                        FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c.label) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cents = Money.parse(amount)
                if (cents == null || cents <= 0) {
                    error = true
                } else {
                    val base = initial ?: Expense(
                        amountCents = 0, description = "", category = cat,
                        timestamp = System.currentTimeMillis(), source = "manual",
                    )
                    onSave(base.copy(amountCents = cents, description = desc.trim().ifEmpty { cat.label }, category = cat))
                }
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
