package com.obed.gastos.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.obed.gastos.R
import com.obed.gastos.data.ExpenseDb
import com.obed.gastos.data.Money
import com.obed.gastos.data.Periods
import com.obed.gastos.ui.AddExpenseActivity
import com.obed.gastos.ui.MainActivity

class QuickAddWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    companion object {
        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, QuickAddWidget::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        private fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val (start, end) = Periods.month(0)
            val total = ExpenseDb.get(ctx).totalBetween(start, end)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

            val addIntent = Intent(ctx, AddExpenseActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            val openIntent = Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            val views = RemoteViews(ctx.packageName, R.layout.widget_quick_add).apply {
                setTextViewText(R.id.widget_total, Money.fmt(total))
                setOnClickPendingIntent(R.id.widget_add, PendingIntent.getActivity(ctx, 1, addIntent, flags))
                setOnClickPendingIntent(R.id.widget_info, PendingIntent.getActivity(ctx, 2, openIntent, flags))
            }
            mgr.updateAppWidget(id, views)
        }
    }
}
