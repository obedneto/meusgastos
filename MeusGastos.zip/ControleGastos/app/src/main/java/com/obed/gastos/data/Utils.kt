package com.obed.gastos.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.Normalizer
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val PT_BR: Locale = Locale.forLanguageTag("pt-BR")

object Money {
    private val fmt = NumberFormat.getCurrencyInstance(PT_BR)

    fun fmt(cents: Long): String = fmt.format(cents / 100.0)

    fun toInput(cents: Long): String = String.format(PT_BR, "%.2f", cents / 100.0)

    /** Aceita "45,90", "45.90", "1.234,56", "R$ 12". */
    fun parse(text: String): Long? {
        var t = text.replace("R$", "").replace(" ", "").replace(" ", "").trim()
        if (t.isEmpty()) return null
        if (t.contains(',')) t = t.replace(".", "").replace(',', '.')
        return t.toBigDecimalOrNull()
            ?.movePointRight(2)
            ?.setScale(0, RoundingMode.HALF_UP)
            ?.toLong()
    }

    /** "1.234,56" -> 123456 */
    fun parseBr(text: String): Long? =
        BigDecimal(text.replace(".", "").replace(',', '.')).movePointRight(2).toLong()
}

object Periods {
    /** Início (inclusive) e fim (exclusive) do mês atual + offset. */
    fun month(offset: Int): Pair<Long, Long> {
        val c = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.MONTH, offset)
        }
        val start = c.timeInMillis
        c.add(Calendar.MONTH, 1)
        return start to c.timeInMillis
    }

    fun monthLabel(start: Long): String =
        SimpleDateFormat("MMMM 'de' yyyy", PT_BR).format(Date(start))
            .replaceFirstChar { it.uppercase(PT_BR) }

    fun short(ts: Long): String = SimpleDateFormat("dd/MM HH:mm", PT_BR).format(Date(ts))
}

fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .lowercase(PT_BR)
        .replace(Regex("\\s+"), " ")
        .trim()
