package com.obed.gastos.data

/**
 * Sugere a categoria pelo nome do estabelecimento que vem no SMS.
 * Se você corrigir a categoria de um lançamento, o app grava uma regra
 * para aquele estabelecimento e ela passa a valer antes destas palavras-chave.
 */
object Categorizer {

    private val rules: List<Pair<Category, List<String>>> = listOf(
        Category.DESPESA_FIXA to listOf(
            "netflix", "spotify", "disney", "prime video", "hbo", "max.com", "youtube premium",
            "energisa", "energia", "sanesul", "agua", "saneamento", "internet", "vivo", "claro",
            " tim ", "oi fibra", "aluguel", "condominio", "seguro", "academia", "smartfit",
            "smart fit", "escola", "faculdade", "mensalidade", "icloud", "google one",
        ),
        Category.SAUDE to listOf(
            "farmac", "drogaria", "droga", "pague menos", "raia", "hospital", "clinica",
            "laborat", "odonto", "otica", "medic",
        ),
        Category.TRANSPORTE to listOf(
            "posto", "combust", "auto posto", "ipiranga", "shell", "petrobras", " br ",
            "uber", "99app", "99 pop", "99pop", "estacion", "pedagio", "sem parar",
            "conectcar", "veloe", "oficina", "auto pecas", "autopecas", "borracharia",
        ),
        Category.COMPRAS to listOf(
            "mercado livre", "mercadolivre", "amazon", "shopee", "shein", "magazine", "magalu",
            "americanas", "casas bahia", "renner", "riachuelo", "c&a", "centauro", "kabum",
            "aliexpress", "havan", "decathlon",
        ),
        Category.ALIMENTACAO to listOf(
            "mercado", "supermerc", "atacad", "assai", "atacadao", "fort ", "comper",
            "padaria", "panific", "restaurante", "lanch", "ifood", "pizza", "burger",
            "mcdonald", "acougue", "hortifruti", "sorvet", "doceria", "cafe", "churrasc",
            "espetinho", "pastel", "conveniencia", "sushi", "food",
        ),
        Category.LAZER to listOf(
            "cinema", "cinemark", "steam", "playstation", "xbox", "nintendo", "ingresso",
            "sympla", "show", " bar ", "pub", "boteco", "choperia", "hotel", "pousada",
            "airbnb", "booking", "clube", "parque", "latam", "gol linhas", "azul linhas",
        ),
    )

    fun guess(merchant: String): Category {
        val n = " " + normalize(merchant) + " "
        for ((cat, words) in rules) if (words.any { n.contains(it) }) return cat
        return Category.OUTROS
    }

    /** Chave usada nas regras aprendidas: nome sem acento e sem números (ex.: filial). */
    fun key(merchant: String): String =
        normalize(merchant).replace(Regex("[0-9*#]+"), " ").replace(Regex("\\s+"), " ").trim().take(24)
}
