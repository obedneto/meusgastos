package com.obed.gastos.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.obed.gastos.data.Categorizer
import com.obed.gastos.data.Expense
import com.obed.gastos.data.ExpenseDb
import com.obed.gastos.data.Periods
import com.obed.gastos.widget.QuickAddWidget

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val body = parts.joinToString("") { it.messageBody.orEmpty() }
        if (!body.contains("bradesco", ignoreCase = true)) return

        val parsed = PurchaseParser.parse(body)
        DiagLog.add(ctx, body, registered = parsed != null)
        if (parsed != null) ExpenseRecorder.record(ctx, parsed)
    }
}

object ExpenseRecorder {
    fun record(ctx: Context, p: ParsedPurchase): Boolean {
        val db = ExpenseDb.get(ctx)
        val now = System.currentTimeMillis()
        if (db.existsRecentAuto(p.amountCents, p.merchant, now - 3 * 60_000)) return false
        val category = db.ruleFor(Categorizer.key(p.merchant)) ?: Categorizer.guess(p.merchant)
        db.insert(
            Expense(
                amountCents = p.amountCents,
                description = p.merchant,
                category = category,
                timestamp = now,
                source = "sms",
            )
        )
        QuickAddWidget.refreshAll(ctx)
        return true
    }
}

/** Guarda os últimos SMS do Bradesco para conferir se a leitura está certa. */
object DiagLog {
    private const val SEP = "\u001E"
    private const val MAX = 20

    fun add(ctx: Context, text: String, registered: Boolean) {
        val prefs = ctx.getSharedPreferences("diag", Context.MODE_PRIVATE)
        val mark = if (registered) "✔ registrado" else "✖ ignorado"
        val entry = "${Periods.short(System.currentTimeMillis())} · $mark\n$text"
        val list = read(ctx).toMutableList().apply { add(0, entry) }.take(MAX)
        prefs.edit().putString("log", list.joinToString(SEP)).apply()
    }

    fun read(ctx: Context): List<String> =
        ctx.getSharedPreferences("diag", Context.MODE_PRIVATE)
            .getString("log", null)
            ?.split(SEP)
            ?.filter { it.isNotBlank() }
            .orEmpty()
}
