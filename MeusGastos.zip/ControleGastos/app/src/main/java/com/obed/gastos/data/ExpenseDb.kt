package com.obed.gastos.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ExpenseDb private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "gastos.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE expenses (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "amount_cents INTEGER NOT NULL," +
                "description TEXT NOT NULL," +
                "category TEXT NOT NULL," +
                "ts INTEGER NOT NULL," +
                "source TEXT NOT NULL," +
                "payment TEXT NOT NULL DEFAULT 'PIX')"
        )
        db.execSQL("CREATE INDEX idx_expenses_ts ON expenses(ts)")
        // Regras aprendidas: quando você muda a categoria de um estabelecimento,
        // as próximas compras nele já entram na categoria certa.
        db.execSQL("CREATE TABLE merchant_rules (merchant TEXT PRIMARY KEY, category TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE expenses ADD COLUMN payment TEXT NOT NULL DEFAULT 'PIX'")
            db.execSQL("UPDATE expenses SET payment='CREDITO' WHERE source='sms'")
        }
    }

    private fun values(e: Expense) = ContentValues().apply {
        put("amount_cents", e.amountCents)
        put("description", e.description)
        put("category", e.category.name)
        put("ts", e.timestamp)
        put("source", e.source)
        put("payment", e.payment.name)
    }

    fun insert(e: Expense): Long = writableDatabase.insert("expenses", null, values(e))

    fun update(e: Expense) {
        writableDatabase.update("expenses", values(e), "id=?", arrayOf(e.id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete("expenses", "id=?", arrayOf(id.toString()))
    }

    fun byPeriod(start: Long, end: Long): List<Expense> {
        val out = mutableListOf<Expense>()
        readableDatabase.rawQuery(
            "SELECT id, amount_cents, description, category, ts, source, payment FROM expenses " +
                "WHERE ts >= ? AND ts < ? ORDER BY ts DESC",
            arrayOf(start.toString(), end.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += Expense(
                    id = c.getLong(0),
                    amountCents = c.getLong(1),
                    description = c.getString(2),
                    category = Category.from(c.getString(3)),
                    timestamp = c.getLong(4),
                    source = c.getString(5),
                    payment = Payment.from(c.getString(6)),
                )
            }
        }
        return out
    }

    fun totalBetween(start: Long, end: Long): Long =
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(amount_cents),0) FROM expenses WHERE ts >= ? AND ts < ?",
            arrayOf(start.toString(), end.toString())
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }

    /** Evita lançar duas vezes o mesmo SMS (ex.: mensagem reenviada pela operadora). */
    fun existsRecentAuto(amountCents: Long, description: String, sinceTs: Long): Boolean =
        readableDatabase.rawQuery(
            "SELECT 1 FROM expenses WHERE amount_cents=? AND description=? AND source!='manual' AND ts>=? LIMIT 1",
            arrayOf(amountCents.toString(), description, sinceTs.toString())
        ).use { it.moveToFirst() }

    fun ruleFor(merchantKey: String): Category? {
        if (merchantKey.isBlank()) return null
        return readableDatabase.rawQuery(
            "SELECT category FROM merchant_rules WHERE merchant=?", arrayOf(merchantKey)
        ).use { c -> if (c.moveToFirst()) Category.from(c.getString(0)) else null }
    }

    fun saveRule(merchantKey: String, category: Category) {
        if (merchantKey.isBlank()) return
        writableDatabase.insertWithOnConflict(
            "merchant_rules", null,
            ContentValues().apply {
                put("merchant", merchantKey)
                put("category", category.name)
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    companion object {
        @Volatile private var instance: ExpenseDb? = null
        fun get(ctx: Context): ExpenseDb =
            instance ?: synchronized(this) { instance ?: ExpenseDb(ctx).also { instance = it } }
    }
}
