package com.obed.gastos.sms

import com.obed.gastos.data.Money
import com.obed.gastos.data.normalize

data class ParsedPurchase(val amountCents: Long, val merchant: String)

/**
 * Lê o SMS de compra do Bradesco Cartões. Exemplos de formato aceitos:
 *  "BRADESCO CARTOES: COMPRA APROVADA NO CARTAO FINAL 1234 EM 01/10/2026 12:34.
 *   VALOR DE R$ 25,90 NO(A) PADARIA XYZ RIBAS DO RI."
 *  "Bradesco: compra de R$ 25,90 aprovada no cartao final 1234 em PADARIA XYZ."
 * Se o seu SMS vier diferente e não for registrado, abra "Capturas" no app,
 * copie o texto e ajuste as regex abaixo.
 */
object PurchaseParser {

    private val amountRx = Regex("""R\$\s*(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2})""")

    private val ignoreWords = listOf(
        "estorn", "cancelad", "cancelamento", "negad", "recusad", "nao aprovad",
        "nao autorizad", "nao realizad", "pagamento recebido", "pagamento de fatura",
    )

    private val merchantRxs = listOf(
        Regex("""NO\s*\(A\)\s+(.+?)(?=\s+EM\s+\d|\s*[.;]\s|\s*[.;]?\s*$)""", RegexOption.IGNORE_CASE),
        Regex("""(?:estabelecimento|local)\s*:?\s+([^,.;]{3,})""", RegexOption.IGNORE_CASE),
        Regex(
            """\bem\s+(?!\d)(?!cartao\b|cartão\b)([A-Za-zÀ-ú0-9*&'\-][A-Za-zÀ-ú0-9*&'.\- ]{2,}?)(?=\s+(?:em|no|na|as|às|dia)\s+\d|\s*[,;]|\.\s|\.?\s*$)""",
            RegexOption.IGNORE_CASE
        ),
    )

    fun parse(raw: String): ParsedPurchase? {
        val text = raw.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        val n = normalize(text)
        if (!n.contains("compra")) return null
        if (ignoreWords.any { n.contains(it) }) return null

        val m = amountRx.find(text) ?: return null
        val cents = runCatching { Money.parseBr(m.groupValues[1]) }.getOrNull() ?: return null
        if (cents <= 0) return null

        val merchant = merchantRxs.firstNotNullOfOrNull { rx ->
            rx.find(text)?.groupValues?.get(1)?.trim()?.trimEnd('.', ',', ';', '-')?.takeIf { it.length >= 3 }
        }?.let(::clean) ?: "Compra no cartão"

        return ParsedPurchase(cents, merchant)
    }

    private fun clean(s: String): String =
        s.replace(Regex("\\s+"), " ").trim().take(40)
            .lowercase()
            .split(' ')
            .joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
}
